package com.valdal14.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TestHashTable {

	@Test
	@DisplayName("")
	void test() {
		fail("Not yet implemented");
	}

}
