package com.valdal14;

public class LinkedList {
	
	private Node node;
	private int size;

	public LinkedList() {
		this.node = new Node();
		this.size = 0;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}

	public Node getNode() {
		return node;
	}

	public void setNode(Node root) {
		this.node = root;
	}
	
	public Node addNode(String value) {
		Node newNode = new Node(value, this.node);
		this.node = newNode;
		this.size += 1;
		return newNode;
	}
	
	public Node findNode(String value) {
		Node thisNode = this.node;
		
		while(thisNode != null) {
			if(thisNode.getValue() == value)
				return thisNode;
			thisNode = thisNode.getNext();
		}
		return null;
	}
	
	
	public boolean removeNode(String value) {
		Node thisNode = this.node;
		Node prevNode = null;
		
		while(thisNode != null && thisNode.getNext() != null) {
			if(thisNode.getValue() == value) {
				prevNode = this.node;
				prevNode.setNext(thisNode.getNext());
				this.setSize(this.getSize() - 1);
				return true;
			}
			prevNode = thisNode;
			thisNode = thisNode.getNext();
		}
		return false;
	}
}
