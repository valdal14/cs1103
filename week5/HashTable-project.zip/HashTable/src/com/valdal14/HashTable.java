package com.valdal14;

public class HashTable {

	private static final int HASHTABLESIZE = 11;
	private LinkedList[] table;
	private int size;
	
	public HashTable() {
		this.table = new LinkedList[HASHTABLESIZE];
		this.size = 0;
	}
	
	/**
	 * Generate the has code given a String key
	 * @param key
	 * @return
	 * @throws HashTableException 
	 */
	private int hashCode(String key) throws HashTableException {
		char[] chars = key.toCharArray();
		int sum = 0;
		
		for(char c : chars) {
			int ascii = (int) c;
			sum += ascii;
		}
		
		int index = sum % this.table.length;
		
		if(index > (HASHTABLESIZE - 1))
			throw new HashTableException(HashTableException.INDEXERROR);
			
		return index;
	}
	
	/**
	 * Returns the value given a String key
	 * @param key
	 * @return
	 * @throws HashTableException 
	 */
	public String get(String key) throws HashTableException {
		int index = this.hashCode(key);
		if(this.table[index] != null){
			return this.table[index].getNode().getValue();
		} else {
			return null;
		}
		
	}
	
	/**
	 * Add a new Node with key and Value and check for collision
	 * @param key
	 * @param value
	 * @throws HashTableException
	 */
	public void put(String key, String value) throws HashTableException {
		int index = this.hashCode(key);
		// if the index is not null add a new Node to the current LinkedList
		if(this.table[index] != null) {
			System.out.println("Collision, same key was used... but the value will be added to the same LinkedList");
			LinkedList currentList = this.table[index];
			currentList.addNode(value);
			this.size += 1;
		} else {
			// add a new node
			LinkedList newLinkedList = new LinkedList();
			newLinkedList.addNode(value);
			this.table[index] = newLinkedList;
			this.size += 1;
		}
	}
	
	/**
	 * Remove a Node by key
	 * @param key
	 * @throws HashTableException
	 */
	public void remove(String key) throws HashTableException {
		int index = this.hashCode(key);
		// check whether the key already exists
		if(this.table[index] != null) {
			LinkedList currentList = this.table[index];
			Node currentNode = currentList.findNode(this.table[index].getNode().getValue());
			boolean wasRemoved = currentList.removeNode(currentNode.getValue());
			if(wasRemoved) {
				System.out.println("Key removed successfully");
				this.size -= 1;
			} else {
				System.out.println("Something went wrong!!!");
			}
		} else {
			System.out.println("Nothing found with the key " + key);
		}
	}
	
	/**
	 * Returns true if the hash table contains the given key 
	 * otherwise returns false
	 * @param key
	 * @return
	 * @throws HashTableException
	 */
	public boolean containsKey(String key) throws HashTableException {
		int index = this.hashCode(key);
		return this.table[index] != null ? true : false;
	}
	
	/**
	 * Returns the size of the hash table
	 * @return
	 */
	public int size() {
		return this.size;
	}
	
	/**
	 * Prints out the has table value by int index
	 */
	public void printHashTable() {
		for(int i = 0; i < this.table.length; i++) {
			if(this.table[i] != null) {
				System.out.println("At index " + i + " we got a node with value: " + this.table[i].getNode().getValue());
			}
			
		}
	}
	
	public class HashTableException extends Exception {
		private static final long serialVersionUID = 1L;
		private static final String INDEXERROR = "The index value is > to the size limit of this Hash Table";
		public HashTableException(String message) {
			super(message);
		}
	}
	
	
}
