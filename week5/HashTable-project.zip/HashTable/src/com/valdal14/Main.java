package com.valdal14;

import com.valdal14.HashTable.HashTableException;

public class Main {

	public static void main(String[] args) {
		HashTable table = new HashTable();
		try {
			// add a new key-value to the hash table
			table.put("Valerio", "Java Developer");
			table.put("Alejandro", "Java Professor");
			table.put("Dario", "JS Developer");
			table.put("Nick", "Account Manager");
			
			// unexpected collision - index 7
			table.put("Leonor", "Marketing Manager");
			
			// forced Collision 
			table.put("Valerio", "Student");
			
			// get value by key
			String valueByKey = table.get("Valerio");
			String valueBykeyTwo = table.get("Alejandro");
			System.out.println("At index Valerio we got the value: " + valueByKey);
			System.out.println("At index Alejandro we got the value: " + valueBykeyTwo);
			
			// remove by key
			table.remove("'Nothing to remove'");
			table.remove("Leonor");
			
			// contains key
			boolean kOne = table.containsKey("Alejandro");
			boolean kTwo = table.containsKey("Valerio");
			
			System.out.println("Was Key Alejandro found? " + kOne);
			System.out.println("Was Key Valerio found?" + kTwo);
			
			// size
			System.out.println("Size of the hash table is: " + table.size());
			
			// print hashtable
			System.out.println("Print Hash Table ------------------");
			table.printHashTable();
			
		} catch (HashTableException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

}
