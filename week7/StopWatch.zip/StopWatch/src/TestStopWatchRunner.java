/*
       A trivial applet that tests the StopWatchTimer component.
       The applet just creates and shows a StopWatchTimer.
 */

import java.awt.*;
import javax.swing.*;

@SuppressWarnings("deprecation")
public class TestStopWatchRunner extends JApplet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void init() {

		StopWatchLabel watch = new StopWatchLabel();
		watch.setFont( new Font("SansSerif", Font.BOLD, 24) );
		watch.setBackground(Color.white);
		watch.setForeground( new Color(180,0,0) );
		watch.setOpaque(true);
		getContentPane().add(watch, BorderLayout.CENTER);

	}

}